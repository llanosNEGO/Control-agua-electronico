from flask import Flask, jsonify, request
import serial
import time

app = Flask(__name__)

# Configuración de la conexión serial
try:
    motor_serial = serial.Serial('COM3', 9600)
    time.sleep(2)  # Tiempo para estabilizar la conexión
except serial.SerialException as e:
    print(f"Error al abrir el puerto serial: {e}")
    motor_serial = None

# Variable para almacenar el estado actual del motor
motor_status = "Desconocido"

@app.route('/control_motor', methods=['POST'])
def control_motor():
    global motor_status
    action = request.args.get('action')

    if motor_serial and motor_serial.is_open:
        if action == 'on':
            motor_serial.write(b'ON')  # Enviar señal para encender el motor
            motor_status = "Motor encendido"
        elif action == 'off':
            motor_serial.write(b'OFF')  # Enviar señal para apagar el motor
            motor_status = "Motor apagado"
        else:
            return jsonify({'status': 'Comando no reconocido'}), 400

        return jsonify({"status": motor_status}), 200
    else:
        return jsonify({'status': 'Error de conexión serial'}), 500

@app.route('/estado_motor', methods=['GET'])
def estado_motor():
    return jsonify({'status': motor_status})

if __name__ == '__main__':
    app.run(debug=True)